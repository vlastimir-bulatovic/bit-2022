export const COUNTER_PAGE = "COUNTER_PAGE";
export const IMAGE_PAGE = "IMAGE_PAGE";