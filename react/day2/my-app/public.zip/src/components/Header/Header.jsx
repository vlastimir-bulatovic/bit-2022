import React, { Component } from 'react';
import './header.css';

export class Header extends Component {
  render() {
    return (
      <header>Header</header>
    )
  }
}

export default Header