import React, { Component } from "react";
import "./app.css";
import CharacterPage from "./pages/CharacterPage/CharacterPage";
import HomePage from "./pages/HomePage/HomePage";

export class App extends Component {
	constructor(props) {
		super(props);

		// bind methods to constructor
		this.getCharacters = this.getCharacters.bind(this);
		this.goToCharacterProfile = this.goToCharacterProfile.bind(this);
		this.goToCharacterList = this.goToCharacterList.bind(this);
		this.changePage = this.changePage.bind(this);

		this.state = {
			data: [],
			isCardClicked: false,
			currentCharacter: {},
			currentPage: 1,
		};
	}

	getCharacters() {
		fetch(
			`https://rickandmortyapi.com/api/character/?page=${this.state.currentPage}`
		)
			.then((res) => res.json())
			.then((res) => this.setState({ data: res.results }))
			.catch((error) => console.log(error));
	}

	goToCharacterProfile(data) {
		this.setState({ currentCharacter: data, isCardClicked: true });
	}

	goToCharacterList() {
		this.setState({ currentCharacter: {}, isCardClicked: false });
	}

	changePage(pageNumber) {
		this.setState({ currentPage: pageNumber });
	}

	render() {
		return (
			<>
				{!this.state.data.length && (
					<button onClick={this.getCharacters}>Fetch data</button>
				)}
				{this.state.isCardClicked ? (
					<CharacterPage characterData={this.state.currentCharacter} handleCharacterList={this.goToCharacterList} />
				) : (
					<HomePage
						handleCharacterProfile={this.goToCharacterProfile}
						handlePagination={this.changePage}
						characters={this.state.data}
					/>
				)}
			</>
		);
	}
}

export default App;
