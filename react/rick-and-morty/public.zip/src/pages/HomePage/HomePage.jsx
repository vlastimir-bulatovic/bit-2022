import React, { Component } from "react";
import Card from "../../components/Card/Card";
import "./homePage.css";

export class HomePage extends Component {
	render() {
		return (
			<main>
				<h1>Character List</h1>

				<div className="card-wrapper">
					{this.props.characters.map((element) => (
						<Card handleCharacterProfile={this.props.handleCharacterProfile} character={element} />
					))}
				</div>
				 
			</main>
		);
	}
}

export default HomePage;
